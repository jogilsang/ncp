# import pyjokes
import boto3

def main(args):
    # return {"joke": pyjokes.get_joke()}
    return {"boto3": boto3.resource('s3')}